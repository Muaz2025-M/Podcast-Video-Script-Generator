# Quick Start Guide (5 minutes)

## Option 1: Local Setup (Recommended)

### Step 1: Install Python (if needed)
```bash
python --version   # Need 3.9+
```

### Step 2: Install dependencies
```bash
cd podcast-script-generator
python -m venv venv
source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Step 3: Run the app
```bash
streamlit run app.py
```
Open your browser to `http://localhost:8501`.

### Step 4: Generate your first script
1. Type a topic (or tick "Use sample topic file")
2. Pick a format (`podcast` / `video`), style (`solo` / `co-host` / `interview`) and length
3. Click **Generate Script**
4. Check the **Script** tab, then download from **Export**

**Time to first script:** ~5 minutes, no API key required.

---

## Option 2: Google Colab

1. Upload this folder to Google Drive
2. Open `notebooks/colab_setup.py` and copy its cells into a new Colab notebook
3. Run the cells in order - no GPU needed, this is a lightweight pipeline

---

## Testing the System (No Setup Needed)

```bash
python -c "
from src.agents.orchestrator import ScriptGenerator
g = ScriptGenerator()
script = g.generate('Why sleep is the most underrated productivity hack')
print('✓ Pipeline working! Runtime:', script['estimated_runtime'])
"
```

### Run the test suite
```bash
pytest tests/ -v
```

---

## (Optional) Turn on real-LLM mode

By default every agent uses a built-in offline template engine - nothing to configure, $0 cost. If you want the Research and Dialogue agents to call a real LLM instead:

```bash
cp .env.example .env
# edit .env and add ANTHROPIC_API_KEY=... or OPENAI_API_KEY=...
pip install anthropic   # or: pip install openai
```

The app auto-detects the key on next run (see the "Generation mode" caption in the sidebar) and falls back to templates automatically if the call ever fails.

---

## Common Issues & Fixes

### "Module not found" error
```bash
pwd   # make sure you're inside podcast-script-generator/
```

### "Port 8501 already in use"
```bash
streamlit run app.py --server.port 8502
```

### Script feels repetitive
That's expected in offline/template mode - it's deterministic by design so results are reproducible for grading. Set an API key (see above) for more varied, LLM-written phrasing.

---

## What's Next?

1. Read the full `README.md` for the architecture diagram
2. Explore `src/agents/orchestrator.py` to see how the 5 agents connect
3. Try all three styles (`solo`, `co-host`, `interview`) on the same topic
4. Edit `data/angles.json` to tune the offline research angles / B-roll ideas
5. Fill in `LAB_REPORT_TEMPLATE.md` with your own write-up

---

## Success Criteria

✅ You're done when:
- `streamlit run app.py` loads without errors
- You can generate a script for any topic in under 10 seconds
- The script has visible `[MM:SS]` timestamps and HOST/GUEST lines
- `pytest tests/ -v` passes all tests

**Estimated time:** 5-10 minutes from now.

---

**🚀 Ready? Run `pip install -r requirements.txt && streamlit run app.py`.**
