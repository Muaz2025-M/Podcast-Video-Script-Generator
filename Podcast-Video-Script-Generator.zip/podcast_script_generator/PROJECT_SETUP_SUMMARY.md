# Project Setup Summary

This is a **fully working** multi-agent pipeline (not just a scaffold) - every
agent in `src/agents/` is implemented and runs end-to-end with zero setup.

## What's implemented

- [x] `ResearchAgent` - offline template engine + optional LLM path
- [x] `OutlineAgent` - time-budgeted segment planner
- [x] `DialogueAgent` - offline template engine + optional LLM path
- [x] `BRollAgent` - keyword-matched visual suggestions
- [x] `ScriptFormatter` - timestamp computation + Markdown/plaintext/JSON export
- [x] `ScriptGenerator` orchestrator wiring all five agents together
- [x] Streamlit UI (`app.py`) with Generate / Script / Export / Help tabs
- [x] Unit tests covering every agent + the full pipeline (`pytest tests/ -v`)
- [x] Offline mode needs **no API key, no GPU, no external service**

## Verified working

```bash
pip install -r requirements.txt
pytest tests/ -v                 # 6/6 passed
streamlit run app.py             # loads cleanly, generates scripts in-browser
```

## To extend with a real LLM

1. `cp .env.example .env`
2. Add `ANTHROPIC_API_KEY=...` (or `OPENAI_API_KEY=...`) to `.env`
3. `pip install anthropic` (or `pip install openai`)
4. Re-run the app - the sidebar will show "Generation mode: LLM online"

No code changes needed - `src/utils/llm_client.py` auto-detects the key.
