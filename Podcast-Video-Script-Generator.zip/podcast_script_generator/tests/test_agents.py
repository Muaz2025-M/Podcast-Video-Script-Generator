"""
Unit tests - run entirely offline (no API key needed), since every agent
has a deterministic template fallback.

    pytest tests/ -v
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.agents.research_agent import ResearchAgent
from src.agents.outline_agent import OutlineAgent
from src.agents.dialogue_agent import DialogueAgent
from src.agents.broll_agent import BRollAgent
from src.agents.orchestrator import ScriptGenerator
from src.utils.text_utils import format_timestamp, seconds_for_words, slugify, keywords

TOPIC = "Why sleep is the most underrated productivity hack"


def test_research_agent_returns_structured_notes():
    agent = ResearchAgent()
    result = agent.research(TOPIC)
    assert result["topic"] == TOPIC
    assert len(result["key_points"]) >= 6
    assert result["source"] in ("llm", "template")


def test_outline_agent_budgets_segments_within_duration():
    research = ResearchAgent().research(TOPIC)
    outline = OutlineAgent().build_outline(research, duration_minutes=10, style="solo")

    assert outline[0]["type"] == "hook"
    assert outline[-1]["type"] == "outro"
    total = sum(seg["target_seconds"] for seg in outline)
    # allow small rounding drift
    assert abs(total - 600) <= 10


def test_dialogue_agent_writes_lines_for_every_segment():
    research = ResearchAgent().research(TOPIC)
    outline = OutlineAgent().build_outline(research, duration_minutes=6, style="interview")
    scripted = DialogueAgent().write_dialogue(outline, TOPIC, style="interview", tone="conversational")

    assert len(scripted) == len(outline)
    for segment in scripted:
        assert len(segment["lines"]) > 0
        for line in segment["lines"]:
            assert line["speaker"] in ("HOST", "GUEST", "CO-HOST")
            assert line["text"].strip() != ""


def test_broll_agent_returns_suggestions_for_body_segments():
    research = ResearchAgent().research(TOPIC)
    outline = OutlineAgent().build_outline(research, duration_minutes=6, style="solo")
    broll = BRollAgent()
    body_segment = next(s for s in outline if s["type"] == "segment")
    suggestions = broll.suggest(body_segment)
    assert 1 <= len(suggestions) <= 3


def test_full_pipeline_produces_timestamped_script():
    generator = ScriptGenerator()
    script = generator.generate(TOPIC, fmt="video", duration_minutes=5, style="solo")

    assert script["total_words"] > 0
    assert script["sections"][0]["start_timestamp"] == "00:00"
    for section in script["sections"]:
        assert section["broll"]  # video format => every segment has b-roll
        for line in section["lines"]:
            assert ":" in line["timestamp"]

    md = generator.generate_report(script)
    assert TOPIC in md
    assert "[00:00]" in md


def test_text_utils_helpers():
    assert format_timestamp(0) == "00:00"
    assert format_timestamp(65) == "01:05"
    assert format_timestamp(3661) == "1:01:01"
    assert seconds_for_words(150) == 60.0
    assert slugify("Hello, World!") == "hello-world"
    assert "sleep" in keywords("why sleep matters for productivity")
