"""
Configuration file for the Automated Podcast/Video Script Generator
"""

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
TOPICS_DIR = DATA_DIR / "topics"
EXPORTS_DIR = DATA_DIR / "exports"
ANGLES_FILE = DATA_DIR / "angles.json"

# --- LLM configuration (all optional - project works with $0 / no keys) ---
# If a key is present AND the matching package is installed, agents will call
# the real model for richer research/dialogue. Otherwise every agent falls
# back to its built-in template engine, so the whole pipeline always runs.
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

# --- Script generation defaults ---
WORDS_PER_MINUTE = 150          # average spoken pace used to compute timestamps
DEFAULT_DURATION_MINUTES = 10
MIN_SEGMENTS = 3
MAX_SEGMENTS = 6

FORMATS = ["podcast", "video"]
STYLES = ["solo", "co-host", "interview"]
TONES = ["conversational", "professional", "energetic", "calm/educational"]

# Logging
LOG_LEVEL = "INFO"
LOG_FILE = PROJECT_ROOT / "logs" / "app.log"

print(
    f"✓ Config loaded | LLM: "
    f"{'Anthropic' if ANTHROPIC_API_KEY else ('OpenAI' if OPENAI_API_KEY else 'offline/template mode')}"
)
