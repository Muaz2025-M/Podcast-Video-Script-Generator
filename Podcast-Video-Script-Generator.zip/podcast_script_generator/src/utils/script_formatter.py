"""Agent 5 (utility): formats the scripted, B-roll-annotated outline into a
ready-to-record script with running timestamps."""

from typing import Dict, Any, List
from datetime import datetime

from src.utils.text_utils import word_count, seconds_for_words, format_timestamp


class ScriptFormatter:

    def build(self, topic: str, scripted: List[Dict[str, Any]], broll: Dict[str, List[str]],
              fmt: str, style: str, tone: str) -> Dict[str, Any]:
        running_seconds = 0.0
        sections = []
        total_words = 0

        for segment in scripted:
            start_ts = format_timestamp(running_seconds)
            segment_words = 0
            rendered_lines = []

            for line in segment["lines"]:
                w = word_count(line["text"])
                segment_words += w
                line_ts = format_timestamp(running_seconds)
                rendered_lines.append({
                    "timestamp": line_ts,
                    "speaker": line["speaker"],
                    "text": line["text"],
                })
                running_seconds += seconds_for_words(w)

            total_words += segment_words
            sections.append({
                "id": segment["id"],
                "title": segment["title"],
                "type": segment["type"],
                "start_timestamp": start_ts,
                "end_timestamp": format_timestamp(running_seconds),
                "lines": rendered_lines,
                "broll": broll.get(segment["id"], []) if fmt == "video" else [],
            })

        return {
            "topic": topic,
            "format": fmt,
            "style": style,
            "tone": tone,
            "generated_at": datetime.now().isoformat(),
            "estimated_runtime_seconds": round(running_seconds),
            "estimated_runtime": format_timestamp(running_seconds),
            "total_words": total_words,
            "sections": sections,
        }

    # -- exporters -------------------------------------------------------
    def to_markdown(self, script: Dict[str, Any]) -> str:
        lines = [
            f"# {script['topic']}",
            "",
            f"**Format:** {script['format'].title()}  |  **Style:** {script['style'].title()}  "
            f"|  **Tone:** {script['tone'].title()}",
            f"**Estimated runtime:** {script['estimated_runtime']}  "
            f"|  **Word count:** {script['total_words']}",
            f"**Generated:** {script['generated_at'][:19].replace('T', ' ')}",
            "",
            "---",
            "",
        ]

        for section in script["sections"]:
            lines.append(f"## [{section['start_timestamp']}] {section['title']}")
            lines.append("")
            if section["broll"]:
                lines.append("**\U0001F3AC B-ROLL / VISUAL CUES:**")
                for cue in section["broll"]:
                    lines.append(f"- {cue}")
                lines.append("")
            for line in section["lines"]:
                lines.append(f"`[{line['timestamp']}]` **{line['speaker']}:** {line['text']}")
                lines.append("")
            lines.append("---")
            lines.append("")

        return "\n".join(lines)

    def to_plaintext(self, script: Dict[str, Any]) -> str:
        lines = [
            script["topic"].upper(),
            f"{script['format'].title()} script | {script['style'].title()} | "
            f"~{script['estimated_runtime']} | {script['total_words']} words",
            "=" * 60,
            "",
        ]
        for section in script["sections"]:
            lines.append(f"[{section['start_timestamp']}] {section['title'].upper()}")
            if section["broll"]:
                lines.append("  B-ROLL: " + "; ".join(section["broll"]))
            for line in section["lines"]:
                lines.append(f"  [{line['timestamp']}] {line['speaker']}: {line['text']}")
            lines.append("")
        return "\n".join(lines)
