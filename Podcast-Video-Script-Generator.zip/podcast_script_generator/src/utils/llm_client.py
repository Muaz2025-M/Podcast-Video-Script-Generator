"""
Thin, optional LLM wrapper.

The whole project is designed to run at $0 with no API key at all: every
agent has a deterministic template fallback. If the user *does* export
ANTHROPIC_API_KEY or OPENAI_API_KEY (and has the matching package
installed), this client is used instead to produce richer, less
repetitive text. Nothing else in the codebase needs to know which path
was used - callers just get back a string, or None if no LLM is
available/the call failed, and they fall back to templates.
"""

import logging
from typing import Optional

from src import config

logger = logging.getLogger(__name__)


class LLMClient:
    """Calls Anthropic or OpenAI if configured; otherwise reports offline."""

    def __init__(self):
        self.provider = None
        self._client = None

        if config.ANTHROPIC_API_KEY:
            try:
                import anthropic  # type: ignore
                self._client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
                self.provider = "anthropic"
            except ImportError:
                logger.warning("ANTHROPIC_API_KEY set but 'anthropic' package not installed.")

        if self.provider is None and config.OPENAI_API_KEY:
            try:
                import openai  # type: ignore
                self._client = openai.OpenAI(api_key=config.OPENAI_API_KEY)
                self.provider = "openai"
            except ImportError:
                logger.warning("OPENAI_API_KEY set but 'openai' package not installed.")

    @property
    def is_online(self) -> bool:
        return self.provider is not None

    def complete(self, system_prompt: str, user_prompt: str, max_tokens: int = 700) -> Optional[str]:
        """Return generated text, or None if offline / the call failed."""
        if not self.is_online:
            return None

        try:
            if self.provider == "anthropic":
                resp = self._client.messages.create(
                    model=config.ANTHROPIC_MODEL,
                    max_tokens=max_tokens,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_prompt}],
                )
                return resp.content[0].text.strip()

            if self.provider == "openai":
                resp = self._client.chat.completions.create(
                    model=config.OPENAI_MODEL,
                    max_tokens=max_tokens,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                )
                return resp.choices[0].message.content.strip()

        except Exception as e:  # pragma: no cover - network/key errors
            logger.error(f"LLM call failed, falling back to templates: {e}")
            return None

        return None
