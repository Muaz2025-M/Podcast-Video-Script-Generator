"""Small text/time helpers shared by multiple agents."""

import re
from src import config


def word_count(text: str) -> int:
    return len(re.findall(r"\S+", text))


def seconds_for_words(n_words: int, wpm: int = config.WORDS_PER_MINUTE) -> float:
    """How many seconds it takes an average speaker to say n_words."""
    return (n_words / wpm) * 60.0


def format_timestamp(total_seconds: float) -> str:
    """Seconds -> 'MM:SS' (or 'H:MM:SS' past an hour)."""
    total_seconds = max(0, int(round(total_seconds)))
    h, rem = divmod(total_seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def slugify(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-") or "untitled"


_STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with",
    "is", "are", "be", "how", "what", "why", "your", "you", "it", "its",
    "this", "that", "about", "into", "from", "as", "at", "by", "can",
}


def keywords(text: str, top_n: int = 4):
    """Very light keyword pull: longer, non-stopword words, de-duplicated."""
    words = re.findall(r"[A-Za-z][A-Za-z\-']+", text.lower())
    seen, out = set(), []
    for w in words:
        if w in _STOPWORDS or len(w) < 4 or w in seen:
            continue
        seen.add(w)
        out.append(w)
        if len(out) >= top_n:
            break
    return out
