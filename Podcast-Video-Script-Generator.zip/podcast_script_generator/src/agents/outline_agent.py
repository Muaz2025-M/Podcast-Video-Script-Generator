"""Agent 2: Outline Agent - turns research notes into a timed segment plan."""

import logging
from typing import Dict, Any, List

from src import config

logger = logging.getLogger(__name__)


class OutlineAgent:
    """Builds a time-budgeted outline from research notes."""

    def build_outline(self, research: Dict[str, Any], duration_minutes: int,
                       style: str = "solo") -> List[Dict[str, Any]]:
        total_seconds = duration_minutes * 60
        points = research["key_points"]

        n_segments = max(config.MIN_SEGMENTS, min(config.MAX_SEGMENTS, len(points)))
        chunks = self._chunk(points, n_segments)
        # _chunk may return slightly more/fewer chunks than requested when the
        # point count doesn't divide evenly - budget time off the real count.
        n_segments = len(chunks)

        hook_s = round(total_seconds * 0.05)
        intro_s = round(total_seconds * 0.10)
        outro_s = round(total_seconds * 0.12)
        body_s = total_seconds - hook_s - intro_s - outro_s
        per_segment = max(30, round(body_s / n_segments))

        outline = [
            {
                "id": "hook",
                "type": "hook",
                "title": "Cold Open / Hook",
                "target_seconds": hook_s,
                "talking_points": [f"A one-line teaser for: {research['topic']}"],
            },
            {
                "id": "intro",
                "type": "intro",
                "title": f"Welcome & Episode Intro ({'Guest' if style == 'interview' else 'Topic'} Setup)",
                "target_seconds": intro_s,
                "talking_points": [
                    f"Welcome listeners, introduce today's topic: {research['topic']}",
                    "Why this topic matters to this audience right now",
                ] + (["Introduce the guest and their background"] if style == "interview" else []),
            },
        ]

        for i, chunk in enumerate(chunks, start=1):
            outline.append({
                "id": f"segment-{i}",
                "type": "qna" if style == "interview" else "segment",
                "title": f"Segment {i}: {self._title_for(chunk[0])}",
                "target_seconds": per_segment,
                "talking_points": chunk,
            })

        outline.append({
            "id": "outro",
            "type": "outro",
            "title": "Recap & Outro",
            "target_seconds": outro_s,
            "talking_points": [
                "Recap the single most important takeaway",
                "Call to action (subscribe / follow / share / comment)",
                "Tease next episode or related content",
            ],
        })

        return outline

    @staticmethod
    def _chunk(items: List[str], n: int) -> List[List[str]]:
        n = max(1, n)
        avg = max(1, round(len(items) / n))
        chunks, i = [], 0
        while i < len(items):
            chunks.append(items[i:i + avg])
            i += avg
        # merge any tiny tail chunk into the previous one
        while len(chunks) > n and len(chunks) > 1:
            tail = chunks.pop()
            chunks[-1].extend(tail)
        return chunks

    @staticmethod
    def _title_for(point: str) -> str:
        words = point.split()
        short = " ".join(words[:6])
        return short.rstrip(".,:;") + ("..." if len(words) > 6 else "")
