"""Agent 1: Research Agent - gathers talking points & angles for a topic."""

import json
import logging
from typing import Dict, Any, List

from src import config
from src.utils.llm_client import LLMClient

logger = logging.getLogger(__name__)


class ResearchAgent:
    """Turns a raw topic string into structured research notes."""

    def __init__(self, llm: LLMClient = None):
        self.llm = llm or LLMClient()
        with open(config.ANGLES_FILE, "r", encoding="utf-8") as f:
            self._bank = json.load(f)

    def research(self, topic: str, audience: str = "general listeners") -> Dict[str, Any]:
        notes = self._research_with_llm(topic, audience)
        source = "llm"
        if notes is None:
            notes = self._research_offline(topic)
            source = "template"

        questions = [
            f"What first got you (or people in general) interested in {topic}?",
            f"What's the one thing most people get wrong about {topic}?",
            f"If a listener only remembers one thing about {topic}, what should it be?",
        ]

        return {
            "topic": topic,
            "audience": audience,
            "source": source,
            "key_points": notes,
            "suggested_questions": questions,
        }

    # -- real LLM path -----------------------------------------------
    def _research_with_llm(self, topic: str, audience: str):
        if not self.llm.is_online:
            return None

        system_prompt = (
            "You are a meticulous podcast/video researcher. Given a topic, "
            "produce 6-8 concise, factual, well-organized talking points a "
            "host could speak from. Flag any specific number/statistic you "
            "are not fully certain of with '[VERIFY]'. Return ONLY a JSON "
            "array of strings, no commentary."
        )
        user_prompt = f"Topic: {topic}\nAudience: {audience}\nReturn the JSON array now."
        raw = self.llm.complete(system_prompt, user_prompt, max_tokens=600)
        if not raw:
            return None
        try:
            start, end = raw.find("["), raw.rfind("]") + 1
            points = json.loads(raw[start:end])
            if isinstance(points, list) and points:
                return [str(p) for p in points]
        except Exception as e:
            logger.warning(f"Could not parse LLM research output, using templates: {e}")
        return None

    # -- offline fallback ----------------------------------------------
    def _research_offline(self, topic: str) -> List[str]:
        notes = []
        for angle in self._bank["research_angles"]:
            notes.append(angle["prompt"].format(topic=topic))
        return notes
