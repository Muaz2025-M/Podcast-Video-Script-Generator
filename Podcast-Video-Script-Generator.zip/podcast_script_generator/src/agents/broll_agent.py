"""Agent 4: B-Roll Agent - suggests visuals for each segment (video format only)."""

import json
import logging
from typing import Dict, Any, List

from src import config
from src.utils.text_utils import keywords

logger = logging.getLogger(__name__)


class BRollAgent:
    """Suggests B-roll / visual cues per segment, keyed off segment keywords."""

    def __init__(self):
        with open(config.ANGLES_FILE, "r", encoding="utf-8") as f:
            self._kw_map = json.load(f)["broll_keyword_map"]

    def suggest(self, scripted_segment: Dict[str, Any]) -> List[str]:
        if scripted_segment["type"] in ("hook", "intro", "outro"):
            return self._generic(scripted_segment)

        text = " ".join(scripted_segment.get("talking_points", []))
        found = keywords(text, top_n=6)

        suggestions: List[str] = []
        for kw in found:
            for bucket, visuals in self._kw_map.items():
                if bucket == "default":
                    continue
                if bucket in kw or kw in bucket:
                    suggestions.extend(visuals)

        if not suggestions:
            suggestions = list(self._kw_map["default"])

        # de-duplicate, keep order, cap at 3
        seen, out = set(), []
        for s in suggestions:
            if s not in seen:
                seen.add(s)
                out.append(s)
            if len(out) >= 3:
                break
        return out

    @staticmethod
    def _generic(segment: Dict[str, Any]) -> List[str]:
        if segment["type"] == "hook":
            return ["fast-cut teaser montage of the episode's best moments"]
        if segment["type"] == "intro":
            return ["title card / channel intro animation", "presenter mid-shot, direct to camera"]
        return ["end-screen with subscribe button + related video thumbnails"]
