"""Agent Orchestrator - coordinates Research -> Outline -> Dialogue ->
B-Roll -> Formatter to turn a topic into a ready-to-record script."""

import logging
from typing import Dict, Any

from src import config
from src.utils.llm_client import LLMClient
from src.utils.script_formatter import ScriptFormatter
from src.agents.research_agent import ResearchAgent
from src.agents.outline_agent import OutlineAgent
from src.agents.dialogue_agent import DialogueAgent
from src.agents.broll_agent import BRollAgent

logger = logging.getLogger(__name__)


class ScriptGenerator:
    """Main orchestrator for the multi-agent script generation pipeline."""

    def __init__(self):
        self.llm = LLMClient()
        self.research_agent = ResearchAgent(self.llm)
        self.outline_agent = OutlineAgent()
        self.dialogue_agent = DialogueAgent(self.llm)
        self.broll_agent = BRollAgent()
        self.formatter = ScriptFormatter()
        logger.info(f"Initialized ScriptGenerator | mode: "
                     f"{'LLM (' + self.llm.provider + ')' if self.llm.is_online else 'offline/template'}")

    def generate(self, topic: str, fmt: str = "podcast", duration_minutes: int = 10,
                 style: str = "solo", tone: str = "conversational",
                 audience: str = "general listeners") -> Dict[str, Any]:
        """Run the full pipeline and return the final, timestamped script."""

        fmt = fmt if fmt in config.FORMATS else "podcast"
        style = style if style in config.STYLES else "solo"

        print(f"\n{'=' * 60}")
        print(f"\U0001F3A7 Generating {fmt} script: \"{topic}\"")
        print(f"{'=' * 60}\n")

        print("\U0001F50E Agent 1: Research Agent")
        print("   → Gathering talking points and angles...")
        research = self.research_agent.research(topic, audience)

        print("\U0001F5C2️  Agent 2: Outline Agent")
        print("   → Budgeting segments against target runtime...")
        outline = self.outline_agent.build_outline(research, duration_minutes, style)

        print("\U0001F3A4 Agent 3: Dialogue Agent")
        print("   → Writing speakable lines per segment...")
        scripted = self.dialogue_agent.write_dialogue(outline, topic, style, tone)

        broll_map = {}
        if fmt == "video":
            print("\U0001F3AC Agent 4: B-Roll Agent")
            print("   → Suggesting shots/visuals per segment...")
            for segment in scripted:
                broll_map[segment["id"]] = self.broll_agent.suggest(segment)
        else:
            print("\U0001F3AC Agent 4: B-Roll Agent")
            print("   → Skipped (podcast format has no visual track)")

        print("\U0001F9FE Agent 5: Script Formatter")
        print("   → Computing timestamps and assembling final script...")
        script = self.formatter.build(topic, scripted, broll_map, fmt, style, tone)

        script["research"] = research
        print(f"\n✓ Done! Estimated runtime: {script['estimated_runtime']} "
              f"({script['total_words']} words)\n")
        return script

    def generate_report(self, script: Dict[str, Any]) -> str:
        """Markdown export - delegates to ScriptFormatter."""
        return self.formatter.to_markdown(script)

    def generate_plaintext(self, script: Dict[str, Any]) -> str:
        return self.formatter.to_plaintext(script)


if __name__ == "__main__":
    generator = ScriptGenerator()
    result = generator.generate(
        topic="Why sleep is the most underrated productivity hack",
        fmt="video",
        duration_minutes=6,
        style="solo",
        tone="conversational",
    )
    print(generator.generate_report(result))
