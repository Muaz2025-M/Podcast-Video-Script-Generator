"""Agent 3: Dialogue Agent - writes speakable host/guest lines per segment."""

import json
import logging
from typing import Dict, Any, List

from src.utils.llm_client import LLMClient

logger = logging.getLogger(__name__)

_TRANSITIONS = [
    "So here's the thing -",
    "Now, let's dig into this -",
    "Okay, this next part is interesting -",
    "Let's break this down -",
    "Here's something worth pausing on -",
]

_WRAPUPS = [
    "a bigger deal than most people realize.",
    "something that changes how a lot of people think about this.",
    "honestly surprising the first time you hear it.",
    "worth sitting with for a second before we move on.",
    "the kind of thing worth keeping in the back of your mind.",
]


class DialogueAgent:
    """Converts outline segments + talking points into spoken dialogue lines."""

    def __init__(self, llm: LLMClient = None):
        self.llm = llm or LLMClient()

    def write_dialogue(self, outline: List[Dict[str, Any]], topic: str,
                        style: str, tone: str) -> List[Dict[str, Any]]:
        scripted = []
        for idx, segment in enumerate(outline):
            lines = self._write_with_llm(segment, topic, style, tone)
            if lines is None:
                lines = self._write_offline(segment, topic, style, idx)
            scripted.append({**segment, "lines": lines})
        return scripted

    # -- real LLM path -----------------------------------------------
    def _write_with_llm(self, segment: Dict[str, Any], topic: str, style: str, tone: str):
        if not self.llm.is_online:
            return None

        speakers = "HOST and GUEST" if style == "interview" else (
            "HOST and CO-HOST" if style == "co-host" else "HOST"
        )
        system_prompt = (
            f"You write natural, speakable {tone} podcast/video dialogue. "
            f"Speakers available: {speakers}. Keep lines short (1-3 sentences), "
            "sound like real speech (contractions, occasional rhetorical "
            "question), and stay on the given talking points. Return ONLY a "
            "JSON array of objects like {\"speaker\": \"HOST\", \"text\": \"...\"}."
        )
        user_prompt = (
            f"Topic: {topic}\nSegment: {segment['title']}\n"
            f"Talking points to cover:\n- " + "\n- ".join(segment["talking_points"]) +
            f"\nTarget length: roughly {segment['target_seconds']} seconds of speech."
        )
        raw = self.llm.complete(system_prompt, user_prompt, max_tokens=700)
        if not raw:
            return None
        try:
            start, end = raw.find("["), raw.rfind("]") + 1
            lines = json.loads(raw[start:end])
            if isinstance(lines, list) and lines:
                return lines
        except Exception as e:
            logger.warning(f"Could not parse LLM dialogue output, using templates: {e}")
        return None

    # -- offline fallback ----------------------------------------------
    def _write_offline(self, segment: Dict[str, Any], topic: str, style: str,
                        idx: int) -> List[Dict[str, Any]]:
        lines: List[Dict[str, Any]] = []
        seg_type = segment["type"]
        points = segment["talking_points"]

        if seg_type == "hook":
            lines.append({"speaker": "HOST",
                           "text": f"Quick question before we start: what do you *really* know about {topic}? "
                                    "Stick around, because today we're going to get into it."})
            return lines

        if seg_type == "intro":
            lines.append({"speaker": "HOST",
                           "text": f"Hey, welcome back to the show! Today we're talking all about {topic}."})
            if style == "interview":
                lines.append({"speaker": "HOST",
                               "text": "And I've got a great guest with me to help break it all down. "
                                        "Thanks so much for joining me today."})
                lines.append({"speaker": "GUEST",
                               "text": "Thanks for having me, happy to be here."})
            else:
                lines.append({"speaker": "HOST",
                               "text": "This is one of those topics that touches more of your daily "
                                        "life than you'd think, so let's get right into it."})
            return lines

        if seg_type == "outro":
            lines.append({"speaker": "HOST",
                           "text": f"So, to wrap up: {points[0] if points else 'that about covers it for today.'}"})
            lines.append({"speaker": "HOST",
                           "text": "If you got something out of this, follow the show, leave a rating, "
                                    "and share it with someone who needs to hear it."})
            lines.append({"speaker": "HOST",
                           "text": "That's it for today - see you in the next one."})
            return lines

        # Regular body / Q&A segment
        transition = _TRANSITIONS[idx % len(_TRANSITIONS)]
        wrap = _WRAPUPS[idx % len(_WRAPUPS)]

        if style == "interview":
            question = points[0] if points else f"Tell me more about {topic}."
            lines.append({"speaker": "HOST", "text": f"{transition} {question}"})
            for i, point in enumerate(points):
                suffix = f" That's {wrap}" if i == len(points) - 1 else ""
                lines.append({"speaker": "GUEST", "text": f"{point}{suffix}"})
            lines.append({"speaker": "HOST", "text": "That's a great way to put it."})
        else:
            first, rest = points[0], points[1:]
            lines.append({"speaker": "HOST", "text": f"{transition} {first}"})
            for point in rest:
                lines.append({"speaker": "HOST", "text": f"On top of that, {point[0].lower()}{point[1:]}"})
            lines.append({"speaker": "HOST", "text": f"That's {wrap}"})

        return lines
