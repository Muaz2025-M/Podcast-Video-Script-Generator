# Lab Report - Automated Podcast/Video Script Generator

**Name:**
**Course:** Agentic AI
**Date:**

## 1. Problem Statement

Scripting a podcast or YouTube video episode end-to-end (research → outline →
dialogue → shot list) is repetitive manual work. This project builds a
multi-agent system that automates the full pipeline from a single topic
string to a ready-to-record, timestamped script.

## 2. System Architecture

_Describe the 5-agent pipeline in your own words. Include the diagram from
`README.md` or redraw it._

| Agent | Responsibility | Input | Output |
| --- | --- | --- | --- |
| Research Agent | Gather talking points/angles | topic, audience | list of key points, suggested questions |
| Outline Agent | Time-budget the episode | research notes, target length | ordered segments with time targets |
| Dialogue Agent | Write speakable lines | outline, style, tone | HOST/GUEST lines per segment |
| B-Roll Agent | Suggest visuals (video only) | segment talking points | 1-3 shot suggestions |
| Script Formatter | Timestamps + export | scripted segments, B-roll | final Markdown/plaintext/JSON script |

## 3. Design Decisions

- **Why a template fallback for every agent?** _(hint: zero-cost, reproducible
  grading, works without any API key or GPU)_
- **How are timestamps computed?** _(hint: average words-per-minute speaking
  pace, applied cumulatively per dialogue line - see `text_utils.py`)_
- **How does style (`solo` / `co-host` / `interview`) change the output?**

## 4. Evaluation

Run the generator on at least **5 different topics** and record:

| # | Topic | Format | Style | Target (min) | Actual Runtime | Word Count | Notes |
| - | --- | --- | --- | --- | --- | --- | --- |
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |

**Qualitative review:** For 2-3 of the generated scripts, read them aloud (or
have someone else do it) and note:
- Does the dialogue sound natural when spoken?
- Are the B-roll suggestions (video mode) relevant to the segment?
- Did the actual runtime land close to the target?

## 5. Offline vs. LLM Mode (optional)

If you tested with `ANTHROPIC_API_KEY` / `OPENAI_API_KEY` set, compare a
script generated offline vs. with the LLM on the same topic. What changed?

## 6. Limitations

- Offline mode talking points are generic angle templates, not topic-specific
  facts - any numeric claim is flagged `[VERIFY]` and must be checked before
  recording.
- Dialogue in offline mode can sound repetitive over many segments.
- B-Roll suggestions are keyword-matched, not visually generated.

## 7. Future Work

_What would you add with more time? (e.g. text-to-speech draft audio, a
fact-checking agent, multi-language support, auto-generated thumbnails...)_

## 8. Conclusion

_2-3 sentences summarizing what the project demonstrates about agentic
pipelines._

## Appendix: Sample Generated Script

_Paste one full generated script (Markdown export) here._
