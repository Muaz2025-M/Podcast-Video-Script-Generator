# Automated Podcast/Video Script Generator

**Agentic AI Mini-Project** | Zero-Cost, Multi-Agent Script Generation

## Overview

A multi-agent AI system that turns a single topic into a **ready-to-record podcast or video script**. Five agents each own one job - research, outlining, dialogue writing, B-roll suggestion, and timestamp formatting - and an orchestrator runs them as a pipeline. It runs completely free, with or without an LLM API key.

**Key Features:**
- 🤖 Multi-agent pipeline (Research → Outline → Dialogue → B-Roll → Formatter)
- 🔎 Research Agent gathers structured talking points for any topic
- 🗂️ Outline Agent budgets a hook/intro/body/outro against your target runtime
- 🎤 Dialogue Agent writes speakable HOST/GUEST lines (solo, co-host, or interview style)
- 🎬 B-Roll Agent suggests shots/visuals per segment (video format)
- 🧾 Output is a fully timestamped script, ready to read on-mic or on-camera
- 💡 Works **offline** out of the box (template engine) - or plug in a real LLM for richer writing
- 🎨 Streamlit web UI (no frontend coding needed)

## Quick Start (5 minutes)

### Option 1: Local Setup

```bash
# Install dependencies
pip install -r requirements.txt

# Run the Streamlit app
streamlit run app.py

# Open browser to http://localhost:8501
```

### Option 2: Google Colab

1. Upload this folder to your Google Drive
2. Open `notebooks/colab_setup.py` in Google Colab (copy its cells into a notebook)
3. Run the cells - generates a script and saves it to `/content/script.md`

### Option 3: Command line

```bash
python -c "
from src.agents.orchestrator import ScriptGenerator
g = ScriptGenerator()
script = g.generate('Why sleep is the most underrated productivity hack',
                     fmt='video', duration_minutes=8, style='solo')
print(g.generate_report(script))
"
```

## Project Structure

```
podcast-script-generator/
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── research_agent.py       # Agent 1: gathers talking points
│   │   ├── outline_agent.py        # Agent 2: time-budgeted segment plan
│   │   ├── dialogue_agent.py       # Agent 3: writes speakable lines
│   │   ├── broll_agent.py          # Agent 4: suggests shots/visuals
│   │   └── orchestrator.py         # Coordinates all agents
│   ├── utils/
│   │   ├── llm_client.py           # Optional Anthropic/OpenAI wrapper
│   │   ├── script_formatter.py     # Agent 5: timestamps + export
│   │   └── text_utils.py           # Timing/word-count/keyword helpers
│   └── config.py                   # Settings
├── data/
│   ├── topics/sample_topic.txt     # Example topic
│   ├── angles.json                 # Offline research angles + B-roll keyword map
│   └── exports/                    # Generated scripts land here
├── notebooks/
│   └── colab_setup.py              # Colab cells
├── tests/
│   └── test_agents.py              # Unit tests (run fully offline)
├── app.py                          # Streamlit app
├── requirements.txt
└── README.md
```

## System Architecture

### Agent Pipeline

```
Topic + Settings (format, style, tone, length)
    ↓
Research Agent
    ├─ Pull 6-9 structured talking points / angles
    └─ Suggested interview questions
    ↓
Outline Agent
    ├─ Hook → Intro → N body segments → Outro
    └─ Time-budgeted against target runtime
    ↓
Dialogue Agent
    ├─ HOST / GUEST / CO-HOST speakable lines per segment
    └─ Natural transitions, contractions, rhetorical questions
    ↓
B-Roll Agent (video format only)
    ├─ Keyword-matched shot/visual suggestions per segment
    └─ Generic cues for hook/intro/outro
    ↓
Script Formatter
    ├─ Running [MM:SS] timestamps from word count & speaking pace
    └─ Markdown / plain-text / JSON export
    ↓
Ready-to-Record Script
```

## Free Technology Stack

| Component | Solution | Cost |
| --- | --- | --- |
| **Agent logic** | Python template engine (default) | Free |
| **LLM (optional)** | Anthropic or OpenAI API, bring your own key | Pay-as-you-go, optional |
| **UI** | Streamlit | Free |
| **Deployment** | Streamlit Community Cloud | Free tier |
| **Version Control** | GitHub | Free |
| **TOTAL (default mode)** | - | **$0** |

The project is designed so the **default mode needs no API key at all** - every agent has a deterministic offline fallback (see `data/angles.json` and the template functions in each agent). Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` (see `.env.example`) only if you want richer, LLM-written research and dialogue.

## Key Files to Edit

1. **`src/agents/research_agent.py`** - change how talking points are generated
2. **`src/agents/dialogue_agent.py`** - change the dialogue style/voice
3. **`src/agents/broll_agent.py`** - add your own shot ideas
4. **`data/angles.json`** - edit the offline research angles & B-roll keyword map
5. **`app.py`** - Streamlit UI

## Testing

```bash
# Run all unit tests (offline, no API key needed)
pytest tests/ -v

# Run a single test
pytest tests/test_agents.py::test_full_pipeline_produces_timestamped_script -v
```

## Resources

- **Streamlit Docs:** https://docs.streamlit.io/
- **Anthropic API Docs:** https://docs.claude.com/
- **OpenAI API Docs:** https://platform.openai.com/docs/

## Next Steps After the Lab

- Add a real text-to-speech step to turn the script into an audio draft
- Add a "fact-check" agent that flags `[VERIFY]` points against a search API
- Support multi-language scripts
- Deploy to Streamlit Community Cloud

## License

MIT - feel free to use for your coursework and beyond.

## Author

**Shaikh Muaz Mustafa**

---

**Happy recording! Start with `QUICKSTART.md`. 🚀**
