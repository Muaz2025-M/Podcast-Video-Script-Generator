"""
Paste these cells into a Google Colab notebook to run the project there.
No GPU is required - this is a lightweight, template/LLM-API pipeline,
not a local model, so the free Colab CPU runtime is enough.
"""

# --- Cell 1: Install dependencies -----------------------------------
# !pip install -q streamlit python-dotenv
# (optional, only if you want real-LLM mode)
# !pip install -q anthropic openai

# --- Cell 2: Clone the repo ------------------------------------------
# !git clone https://github.com/YOUR_USERNAME/podcast-script-generator.git
# %cd podcast-script-generator

# --- Cell 3: (Optional) set an API key for real-LLM mode -------------
# import os
# os.environ["ANTHROPIC_API_KEY"] = "sk-ant-..."   # or OPENAI_API_KEY

# --- Cell 4: Generate a script ---------------------------------------
# from src.agents.orchestrator import ScriptGenerator
#
# generator = ScriptGenerator()
# script = generator.generate(
#     topic="Why sleep is the most underrated productivity hack",
#     fmt="video",          # "podcast" or "video"
#     duration_minutes=8,
#     style="solo",         # "solo", "co-host", "interview"
#     tone="conversational",
# )
# print(generator.generate_report(script))

# --- Cell 5: Save the script to Drive ---------------------------------
# with open("/content/script.md", "w") as f:
#     f.write(generator.generate_report(script))
# print("Saved to /content/script.md - download it from the Colab file panel.")
