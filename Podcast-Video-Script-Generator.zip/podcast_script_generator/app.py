"""
Streamlit Web Interface for the Automated Podcast/Video Script Generator
"""
import sys
import json
from pathlib import Path
from datetime import datetime

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))

from src import config
from src.agents.orchestrator import ScriptGenerator


st.set_page_config(
    page_title="Podcast/Video Script Generator",
    page_icon="\U0001F3A7",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
    <style>
    .segment-card {
        background-color: #f0f2f6;
        padding: 16px 18px;
        border-radius: 10px;
        margin: 10px 0;
        border-left: 5px solid #6c5ce7;
    }
    .broll-box {
        background-color: #fff8e1;
        border-left: 5px solid #f9a825;
        padding: 10px 14px;
        border-radius: 6px;
        margin: 8px 0;
        font-size: 0.9em;
    }
    .dialogue-line {
        margin: 6px 0;
        line-height: 1.5;
    }
    .speaker-tag {
        font-weight: 700;
        color: #6c5ce7;
    }
    .ts-tag {
        color: #888;
        font-family: monospace;
        margin-right: 6px;
    }
    </style>
""", unsafe_allow_html=True)

if "script" not in st.session_state:
    st.session_state.script = None


def render_segment(section: dict):
    with st.container():
        st.markdown(
            f"<div class='segment-card'><strong>[{section['start_timestamp']} "
            f"→ {section['end_timestamp']}] {section['title']}</strong></div>",
            unsafe_allow_html=True,
        )
        if section["broll"]:
            cues = "<br>".join(f"\U0001F3AC {c}" for c in section["broll"])
            st.markdown(f"<div class='broll-box'>{cues}</div>", unsafe_allow_html=True)
        for line in section["lines"]:
            st.markdown(
                f"<div class='dialogue-line'><span class='ts-tag'>[{line['timestamp']}]</span>"
                f"<span class='speaker-tag'>{line['speaker']}:</span> {line['text']}</div>",
                unsafe_allow_html=True,
            )


def main():
    with st.sidebar:
        st.title("\U0001F3A7 Script Generator")
        st.markdown("---")
        st.subheader("About")
        st.info(
            "Agents research, outline, write dialogue, suggest B-roll, and "
            "produce a ready-to-record script with timestamps."
        )
        st.markdown("---")
        mode = "LLM online (%s)" % config.ANTHROPIC_MODEL if config.ANTHROPIC_API_KEY else (
            "LLM online (%s)" % config.OPENAI_MODEL if config.OPENAI_API_KEY else "Offline / template mode"
        )
        st.caption(f"Generation mode: **{mode}**")

    st.title("Automated Podcast / Video Script Generator")
    st.markdown(
        "Give it a topic and a target length - a 5-agent pipeline researches it, "
        "outlines it, writes the dialogue, suggests B-roll (for video), and "
        "hands you back a timestamped, ready-to-record script."
    )

    tab1, tab2, tab3, tab4 = st.tabs(
        ["\U0001F4DD Generate", "\U0001F4C4 Script", "\U0001F4E4 Export", "❓ Help"]
    )

    with tab1:
        st.subheader("Episode Setup")

        col1, col2 = st.columns([2, 1])
        with col1:
            topic = st.text_input(
                "Topic",
                value="Why sleep is the most underrated productivity hack",
                help="Whatever you'd talk about on the episode.",
            )
        with col2:
            use_sample = st.checkbox("Use sample topic file", value=False)

        col1, col2, col3, col4 = st.columns(4)
        with col1:
            fmt = st.selectbox("Format", config.FORMATS, index=0)
        with col2:
            style = st.selectbox("Style", config.STYLES, index=0)
        with col3:
            tone = st.selectbox("Tone", config.TONES, index=0)
        with col4:
            duration = st.slider("Target length (min)", 3, 30, config.DEFAULT_DURATION_MINUTES)

        generate_btn = st.button("\U0001F680 Generate Script", type="primary", use_container_width=True)

        if generate_btn:
            final_topic = topic
            if use_sample:
                sample_path = config.TOPICS_DIR / "sample_topic.txt"
                if sample_path.exists():
                    final_topic = sample_path.read_text(encoding="utf-8").strip()

            if not final_topic:
                st.warning("Please enter a topic or use the sample.")
            else:
                with st.spinner("Agents are working..."):
                    try:
                        generator = ScriptGenerator()
                        result = generator.generate(
                            topic=final_topic, fmt=fmt, duration_minutes=duration,
                            style=style, tone=tone,
                        )
                        st.session_state.script = result
                        st.success(
                            f"✓ Script ready! Estimated runtime: "
                            f"{result['estimated_runtime']} ({result['total_words']} words)"
                        )
                    except Exception as e:
                        st.error(f"Error generating script: {e}")

    with tab2:
        if st.session_state.script:
            script = st.session_state.script

            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Estimated Runtime", script["estimated_runtime"])
            with col2:
                st.metric("Word Count", script["total_words"])
            with col3:
                st.metric("Segments", len(script["sections"]))

            with st.expander("\U0001F50E Research notes used for this script"):
                for point in script["research"]["key_points"]:
                    st.write(f"• {point}")

            st.markdown("---")
            for section in script["sections"]:
                render_segment(section)
        else:
            st.info("\U0001F4DD Generate a script in the first tab to see it here.")

    with tab3:
        if st.session_state.script:
            script = st.session_state.script
            generator = ScriptGenerator()

            md = generator.generate_report(script)
            txt = generator.generate_plaintext(script)
            js = json.dumps(script, indent=2, default=str)

            st.download_button("\U0001F4DD Download Markdown (.md)", data=md,
                                file_name="script.md", mime="text/markdown",
                                use_container_width=True)
            st.download_button("\U0001F4C4 Download Plain Text (.txt)", data=txt,
                                file_name="script.txt", mime="text/plain",
                                use_container_width=True)
            st.download_button("\U0001F5C2️ Download JSON (.json)", data=js,
                                file_name="script.json", mime="application/json",
                                use_container_width=True)

            st.markdown("---")
            st.subheader("Markdown preview")
            st.code(md, language="markdown")
        else:
            st.info("\U0001F4DD Generate a script first to export it.")

    with tab4:
        st.subheader("How it works")
        st.markdown("""
        1. **Research Agent** turns your topic into 6-9 structured talking points
           (using a real LLM if `ANTHROPIC_API_KEY` / `OPENAI_API_KEY` is set,
           otherwise a built-in offline template engine - the app always runs).
        2. **Outline Agent** budgets those points into a hook, intro, body
           segments, and an outro, sized to your target runtime.
        3. **Dialogue Agent** writes speakable HOST/GUEST lines for every segment.
        4. **B-Roll Agent** (video format only) suggests shots/visuals per segment.
        5. **Script Formatter** computes running timestamps from an average
           speaking pace and assembles the final, ready-to-record script.

        ### Tips
        - Use **Interview** style to get HOST questions + GUEST answer drafts.
        - Switch to **Video** format to get B-roll cues alongside the dialogue.
        - Export to Markdown for a teleprompter-style read, or JSON if you want
          to feed the script into another tool.
        """)


if __name__ == "__main__":
    main()
